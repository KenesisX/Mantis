# 🧠 PsychoMantis

> *"I can read your mind..."*

A **Tamagotchi-style psychic companion** — a moody, autonomous virtual pet in the
lineage of the handheld recon-pets (pwnagotchi's expressive face & autonomous
life, Bjorn's tool/task list, and the old-school terminal-pet aesthetic), all
re-skinned as **Psycho Mantis of FOXHOUND**.

He lives on his own, senses the ether around him, gains **XP** across **100
psychic levels** (capped by the title **PSYCHO MANTIS**), cycles through **70
moods**, unlocks a **spellbook** of tools, commits fictional villain **deeds**
(possessions, kidnappings, severings) for **souls**, spends souls on permanent
**augments**, grows a **darkness** meter, and reacts to you with a full-body
floating figure, emotions, mannerisms and phrases in his voice.

Runs **anywhere Python 3.8+ runs**, with **zero dependencies** (standard library
only). Two front-ends: a slick **web dashboard** (gas-mask face, CRT scanlines,
psychic effects) and a live **terminal UI**.

---

## ⚡ Quick start

```bash
cd psychomantis
python3 -m psychomantis          # web dashboard → http://127.0.0.1:8777
```

or the launcher:

```bash
./run.sh            # web (default)
./run.sh tui        # terminal pet
```

Open the printed URL in any browser. Feed him, let him meditate, and cast spells.

---

## 🎮 What you can do

| Care action | Effect |
|-------------|--------|
| 🧠 **Feed** | restores psychic *hunger* |
| 🌙 **Rest** | restores *energy* |
| 🧘 **Meditate** | restores *focus* + *sanity* and charges **PSYCHE** |
| 🤍 **Pet** | restores *sanity* (he's fragile) |
| 💬 **Speak** | pull a fresh line from his mind |

He also **acts on his own** (pwnagotchi-style): while running he periodically
*senses the ether* and gains XP without you.

### Needs & mood
Four needs decay over real time — **hunger, energy, focus, sanity** — plus a
**PSYCHE** power meter you spend on spells. His **mood** (watching, smug, hungry,
sleeping, distracted, broken, overcharged, casting…) changes his **face** and the
**phrases** he speaks.

### 70 moods
His **mood** is chosen contextually from 70 states across clusters — idle,
content, smug, hunger, low-energy, low-focus, low-sanity, broken, overcharged,
dark, and event moods (casting, possessing, hunting, severing, kidnapping,
harvesting, enraged, grieving, ascending). Each drives a distinct **full-body
pose, eyes, aura and floating effect** on the e-ink, plus its own phrase bank.
High **darkness** pushes him toward sinister, cruel and wrathful moods.

### 100 levels & ranks
Every action, spell and deed grants XP across **100 levels**. Ranks climb from
`Dormant Psyche → Telepath → Mind Render → Nightmare Weaver → Puppeteer →
Soul Harvester → Void Seer → Mind Tyrant → Most Powerful Psychic →` and finally
**`PSYCHO MANTIS`** at level 100 (with ✦ prestige stars beyond).

### 🖤 Dark deeds, souls & darkness  *(pure fiction)*
At higher levels he can perform villain **deeds** on *invented* NPC minds —
**Haunt, Possess, Kidnap, Sever** — plus **Harvest** captured minds into
**◇ souls**. Deeds raise his **darkness** and **infamy**, add **kills /
kidnappings / possessions** counters, and feed his legend.

> These deeds are **theatrical fiction** acting on randomly-named fictional
> characters. They are completely separate from the real recon tools and touch
> no real person, network or device.

### 🕯 Augments (the shop)
Spend souls on **8 permanent upgrades** (each multi-tier): Psyche Well (+max
PSYCHE), Deep Mind (regen), Sharpened Will (+XP), Iron Sanity, Soul Eater
(+souls/deed), Hungerless Flesh, Dark Mastery (cheaper deeds), Dread Aura.

---

## 📖 The Spellbook (tools)

Each spell is a **real but deliberately safe/benign** operation:

| Spell | Lv | What it really does |
|-------|----|---------------------|
| 👁 **Mind Reading** | 1 | Lists nearby **Wi-Fi networks** — passive read-only, the same list your phone shows |
| 🔮 **Clairvoyance** | 2 | Maps **your own** local subnet (host discovery / "who's on my Wi-Fi") |
| 🛡 **The Veil** | 3 | Audits **your own machine's** open ports and flags risky ones (defensive) |
| 📡 **Telepathy** | 4 | Pings devices you already know to see which are "present" |
| 🌌 **Astral Projection** | 5 | `traceroute` to a host — maps the path your packets take |
| 💠 **Hydro-Quartz Gaze** | 6 | DNS resolution of a name |
| ✨ **Psychokinesis** | 7 | Cosmetic "move the controller" theatre (no network action) |
| 🔥 **Soul Scream** | 10 | Ultimate — dramatic psychic cry, huge XP (purely theatrical) |

> **Safety by design.** PsychoMantis contains **no** deauthentication, packet
> injection, monitor-mode capture, handshake harvesting, or password-cracking
> code. It performs only passive listing, scans of *your own* machine/LAN, and
> ordinary diagnostics any user may run. If a platform tool is missing, spells
> fall back to a thematic simulation so the pet always works.

---

## 🖤 Raspberry Pi e-ink (2.13") — the real handheld

PsychoMantis renders a **pure 1-bit black/white**, full-body **floating
Psycho Mantis figure** — gas-masked head, leather coat with tattered tails,
arms posed by mood, bare dangling feet, and a psychic aura — sized exactly for
the **250×122 2.13" e-paper** panels (Waveshare e-Paper HAT or Pimoroni Inky
pHAT), just like a pwnagotchi. Across the **70 moods** his pose, eyes, aura and
floating effects all change: arms raised + lightning when overcharged, a curled
fetal ball when grieving, chains when kidnapping, a skull when cruel, a crown
when a tyrant, Zzz asleep, cracked lenses when broken, psi-waves + a tarot card
when casting. The panel also shows PSYCHE / XP / **DARKNESS** bars, souls,
infamy, and kill / kidnap / possession counts.

Preview every face without hardware:

```bash
python3 -m psychomantis faces        # writes PNGs + a contact sheet
```

Run it on the panel (auto-detects Waveshare, then Inky, else writes previews):

```bash
python3 -m psychomantis eink --interval 30 --rotate 0
```

One-command Pi install (deps, SPI, driver, auto-start service):

```bash
cd psychomantis && ./deploy/install_pi.sh
```

That installs a **systemd service** (`deploy/psychomantis-eink.service`) so the
Mantis boots with the Pi and keeps living on the screen. Hardware extras are in
`requirements-eink.txt` (only needed for the physical panel — the web/terminal
pet need nothing). The renderer refreshes **only when his face/phrase/level
changes**, to spare the e-ink from ghosting and wear.

Panel wiring: seat the 2.13" HAT on the 40-pin header, `sudo raspi-config` →
Interface → **SPI on**, reboot. Waveshare V2/V3/V4 and Inky pHAT are
auto-detected; force one with `--driver waveshare` or `--driver inky`.

### 🎛️ Physical buttons + idle animation

Five GPIO buttons map to actions (auto no-op if no GPIO):

| Button | Action | Default pin (BCM) |
|--------|--------|-------------------|
| 1 | 🧠 Feed | GPIO 5 |
| 2 | 🧘 Meditate | GPIO 6 |
| 3 | 🤍 Pet | GPIO 16 |
| 4 | ✦ Cast best spell | GPIO 24 |
| 5 | ☠ Commit a dark deed | GPIO 26 |

Buttons and a **2-frame idle float animation** (he gently bobs while calm) are
**on by default** in `eink` mode. Change pins or turn features off:

```bash
python3 -m psychomantis eink --pins "feed=5,meditate=6,pet=16,cast=24,deed=26"
python3 -m psychomantis eink --no-buttons --no-animate
```

Wire each button between its GPIO pin and **GND** (internal pull-ups are
enabled). Needs `RPi.GPIO` (installed by `deploy/install_pi.sh`).

## 🖥️ CLI reference

```bash
python -m psychomantis            # web dashboard (default)
python -m psychomantis web --port 9000 --host 0.0.0.0
python -m psychomantis eink        # drive the Pi 2.13" e-ink panel
python -m psychomantis faces       # bake the 1-bit mood faces to PNG
python -m psychomantis tui        # live terminal pet
python -m psychomantis status     # one-shot status
python -m psychomantis spells      # list the spellbook
python -m psychomantis cast mind_reading
python -m psychomantis feed|rest|meditate|pet
python -m psychomantis possess|kidnap|sever|haunt   # dark deeds (fiction)
python -m psychomantis harvest                       # convert captives → souls
python -m psychomantis shop                          # list augments
python -m psychomantis buy psyche_well               # purchase an augment
```

State is saved to `~/.psychomantis/soul.json` (override with `--home` or the
`PSYCHOMANTIS_HOME` env var). He remembers everything between sessions — his
level, his relics, the minds he's heard.

---

## 🧩 Architecture

```
psychomantis/
├── __main__.py      CLI dispatch
├── engine.py        pet state, needs decay, XP/levels, persistence, event log
├── personality.py   faces, moods, ranks, the Psycho Mantis voice
├── spells.py        the spellbook — safe passive tools + fallbacks
├── tui.py           live terminal interface (ANSI)
├── server.py        stdlib HTTP server: JSON API + autonomous ticker
└── web/             index.html · style.css · app.js  (the dashboard)
```

No pip install required. No internet required. Pure Python + one HTML page.

Made as a fan tribute. Metal Gear Solid and Psycho Mantis are property of Konami;
this is an unofficial, non-commercial homage.
