"""Physical GPIO buttons for the Raspberry Pi handheld.

Maps real buttons to pet actions (feed / meditate / pet / cast / deed). Works on
any Pi via RPi.GPIO; if that library is missing (e.g. on a laptop), it degrades
to a no-op so the rest of the program runs unchanged.

Default pin map (BCM numbering) matches the common 4-button e-ink setups
(e.g. Inky Impression / Waveshare button add-ons). Override with --pins or the
PSYCHOMANTIS_PINS env var, e.g.  PSYCHOMANTIS_PINS="feed=5,meditate=6,pet=16,cast=24,deed=26".
"""

from __future__ import annotations

import os
import threading
from typing import Callable, Dict, Optional

DEFAULT_PINS: Dict[str, int] = {
    "feed": 5, "meditate": 6, "pet": 16, "cast": 24, "deed": 26,
}


def parse_pins(spec: Optional[str]) -> Dict[str, int]:
    pins = dict(DEFAULT_PINS)
    spec = spec or os.environ.get("PSYCHOMANTIS_PINS")
    if spec:
        for part in spec.split(","):
            if "=" in part:
                k, v = part.split("=", 1)
                try:
                    pins[k.strip()] = int(v)
                except ValueError:
                    pass
    return pins


class ButtonPad:
    """Wires GPIO pins to callbacks. Safe no-op when GPIO is unavailable."""

    def __init__(self, actions: Dict[str, Callable[[], None]],
                 pins: Optional[Dict[str, int]] = None, bounce_ms: int = 300):
        self.available = False
        self._actions = actions
        self._pins = pins or parse_pins(None)
        self._lock = threading.Lock()
        self.GPIO = None
        try:
            import RPi.GPIO as GPIO  # type: ignore
            self.GPIO = GPIO
            GPIO.setwarnings(False)
            GPIO.setmode(GPIO.BCM)
            for name, cb in actions.items():
                pin = self._pins.get(name)
                if pin is None:
                    continue
                GPIO.setup(pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
                GPIO.add_event_detect(
                    pin, GPIO.FALLING,
                    callback=self._make_handler(name), bouncetime=bounce_ms)
            self.available = True
        except Exception:
            # no GPIO on this machine — buttons simply do nothing
            self.available = False

    def _make_handler(self, name: str):
        def handler(_pin):
            cb = self._actions.get(name)
            if cb:
                with self._lock:
                    try:
                        cb()
                    except Exception:
                        pass
        return handler

    def describe(self) -> str:
        return ", ".join(f"{n}=GPIO{self._pins.get(n)}" for n in self._actions)

    def cleanup(self) -> None:
        if self.GPIO is not None:
            try:
                self.GPIO.cleanup()
            except Exception:
                pass
