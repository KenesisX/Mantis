"""E-ink renderer: a full-body floating Psycho Mantis Tamagotchi for the Pi 2.13".

Draws a small MGS-styled figure — gas-masked head, leather coat with tattered
tails, arms posed by mood, bare dangling feet, and a psychic aura — in strict
1-bit black/white at 250x122, then composes it with an expanded stat panel
(PSYCHE / XP / DARKNESS bars, souls, infamy, kills / kidnaps / possessions).

The figure's eyes, pose, aura and floating effects all change with the mood, so
each of the 70 moods reads differently on the panel.

Auto-detects Waveshare 2.13" (epd2in13_V2/V3/V4) or Pimoroni Inky; otherwise
writes scaled PNG previews so you can develop without hardware.
"""

from __future__ import annotations

import math
import os
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

from PIL import Image, ImageDraw, ImageFont

WIDTH, HEIGHT = 250, 122
BLACK, WHITE = 0, 255


def _font(size: int) -> ImageFont.ImageFont:
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()


F_BIG, F_MED, F_SM = _font(15), _font(12), _font(9)


def _tw(d, s, f):
    try:
        b = d.textbbox((0, 0), s, font=f)
        return b[2] - b[0]
    except Exception:
        return len(s) * 6


# --------------------------------------------------------------------------- #
# Eyes on the mask lenses
# --------------------------------------------------------------------------- #
def _lens(d, lx, ly, r, eyes):
    d.ellipse([lx - r - 1, ly - r - 1, lx + r + 1, ly + r + 1], fill=BLACK)
    d.ellipse([lx - r, ly - r, lx + r, ly + r], fill=WHITE, outline=BLACK)
    if eyes == "closed":
        d.line([(lx - r + 1, ly), (lx + r - 1, ly)], fill=BLACK, width=2); return
    if eyes == "half":
        d.rectangle([lx - r, ly - r, lx + r, ly - 1], fill=BLACK); return
    if eyes == "cross":
        d.line([(lx - r + 2, ly - r + 2), (lx + r - 2, ly + r - 2)], fill=BLACK, width=2)
        d.line([(lx - r + 2, ly + r - 2), (lx + r - 2, ly - r + 2)], fill=BLACK, width=2); return
    if eyes == "star":
        for a in (0, 45, 90, 135):
            dx, dy = int(r * math.cos(math.radians(a))), int(r * math.sin(math.radians(a)))
            d.line([(lx - dx, ly - dy), (lx + dx, ly + dy)], fill=BLACK, width=1)
        return
    if eyes == "cracked":
        d.ellipse([lx - r, ly - r, lx + r, ly + r], outline=BLACK, width=2)
        d.line([(lx - r, ly - 1), (lx, ly + 2), (lx + r, ly - 2)], fill=BLACK)
        d.line([(lx, ly - r), (lx, ly + r)], fill=BLACK); return
    if eyes == "spiral":
        pr = r
        for a in range(0, 540, 45):
            pr2 = r * (1 - a / 600)
            x = lx + int(pr2 * math.cos(math.radians(a)))
            y = ly + int(pr2 * math.sin(math.radians(a)))
            d.point((x, y), fill=BLACK); d.point((x + 1, y), fill=BLACK)
        return
    if eyes == "tear":
        d.ellipse([lx - 2, ly - 2, lx + 2, ly + 2], fill=BLACK)
        d.line([(lx, ly + 2), (lx, ly + r + 3)], fill=BLACK, width=1); return
    if eyes == "slit":
        d.ellipse([lx - r, ly - 2, lx + r, ly + 2], fill=BLACK); return
    if eyes == "glow":
        d.ellipse([lx - r + 2, ly - r + 2, lx + r - 2, ly + r - 2], fill=BLACK)
        d.ellipse([lx - 1, ly - 1, lx + 1, ly + 1], fill=WHITE); return
    # normal / narrow / wide pupils
    pr = {"narrow": 1, "wide": max(3, r // 2 + 1)}.get(eyes, max(2, r // 2))
    d.ellipse([lx - pr, ly - pr, lx + pr, ly + pr], fill=BLACK)
    d.point((lx - 1, ly - 1), fill=WHITE)


# --------------------------------------------------------------------------- #
# Full figure
# --------------------------------------------------------------------------- #
def draw_figure(img, box, sprite):
    x, y, w, h = box
    d = ImageDraw.Draw(img)
    eyes = sprite.get("eyes", "normal")
    aura = sprite.get("aura", "none")
    pose = sprite.get("pose", "float")
    fx = sprite.get("fx", "none")

    cx = x + w // 2
    head_r = max(9, int(w * 0.26))
    head_cy = y + head_r + 10
    sh_y = head_cy + head_r                       # shoulder line
    hip_y = sh_y + int(h * 0.26)
    sw = int(w * 0.26)                            # shoulder half width

    if pose == "curl":
        _draw_curled(d, cx, (y + y + h) // 2, int(w * 0.42), eyes, aura, fx)
        _aura(d, cx, (y + y + h) // 2, w, h, aura)
        _fx(d, cx, head_cy, head_r, w, h, fx)
        return

    # aura behind the body
    _aura(d, cx, head_cy, w, h, aura)

    # --- coat tails (tattered) below the hips --------------------------- #
    tail_bottom = y + h - 2
    tat = []
    steps = 6
    for i in range(steps + 1):
        tx = cx - sw - 4 + int((2 * (sw + 4)) * i / steps)
        ty = tail_bottom - (6 if i % 2 else 0)
        tat.append((tx, ty))
    d.polygon([(cx - sw, hip_y), (cx + sw, hip_y)] + list(reversed(tat)), fill=BLACK)

    # --- legs (dangling, floating) -------------------------------------- #
    for sgn in (-1, 1):
        lx0 = cx + sgn * int(sw * 0.4)
        d.line([(lx0, hip_y), (lx0, hip_y + int(h * 0.22))], fill=BLACK, width=4)
        fx0 = lx0
        d.ellipse([fx0 - 3, hip_y + int(h * 0.22) - 2, fx0 + 3, hip_y + int(h * 0.22) + 2],
                  fill=BLACK)  # bare foot

    # --- torso (leather) ------------------------------------------------ #
    d.polygon([(cx - sw, sh_y), (cx + sw, sh_y),
               (cx + int(sw * 0.7), hip_y), (cx - int(sw * 0.7), hip_y)], fill=BLACK)
    # strap highlights
    d.line([(cx - sw + 2, sh_y + 6), (cx + sw - 2, sh_y + 6)], fill=WHITE)
    d.line([(cx - sw + 4, sh_y + 6), (cx + int(sw * 0.7) - 2, hip_y - 3)], fill=WHITE)
    d.line([(cx + sw - 4, sh_y + 6), (cx - int(sw * 0.7) + 2, hip_y - 3)], fill=WHITE)

    # --- arms (pose) ---------------------------------------------------- #
    hands = _arms(d, cx, sh_y, sw, head_cy, head_r, hip_y, w, h, pose)

    # --- head / gas mask ------------------------------------------------ #
    _head(d, cx, head_cy, head_r, eyes)

    # --- floating effects ----------------------------------------------- #
    _fx(d, cx, head_cy, head_r, w, h, fx, hands)


def _head(d, cx, cy, r, eyes):
    # spiky hair
    for i in range(-2, 3):
        hx = cx + i * (r // 2)
        d.polygon([(hx - 3, cy - r + 2), (hx + 3, cy - r + 2), (hx, cy - r - 7)], fill=BLACK)
    # hood/head
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=BLACK)
    d.polygon([(cx - r + 2, cy + r // 2), (cx + r + 2, cy + r // 2),
               (cx + r // 2, cy + r + 5), (cx - r // 2, cy + r + 5)], fill=BLACK)
    # lenses
    lr = max(3, int(r * 0.42))
    ly = cy - int(r * 0.15)
    _lens(d, cx - int(r * 0.42), ly, lr, eyes)
    _lens(d, cx + int(r * 0.42), ly, lr, eyes)
    # breathing filter
    fw = max(4, int(r * 0.5))
    fy = cy + int(r * 0.55)
    d.rounded_rectangle([cx - fw // 2, fy, cx + fw // 2, fy + int(r * 0.5)],
                        radius=2, fill=WHITE, outline=BLACK)


def _arms(d, cx, sh_y, sw, head_cy, head_r, hip_y, w, h, pose):
    L = (cx - sw, sh_y + 3)
    R = (cx + sw, sh_y + 3)
    far = int(w * 0.46)
    if pose == "arms_raised":
        hl = (cx - sw - 6, head_cy - head_r - 6); hr = (cx + sw + 6, head_cy - head_r - 6)
    elif pose in ("arms_out", "crucifix"):
        ext = far if pose == "crucifix" else int(w * 0.40)
        hl = (cx - ext, sh_y + (0 if pose == "crucifix" else 4))
        hr = (cx + ext, sh_y + (0 if pose == "crucifix" else 4))
    elif pose == "reach":
        hl = (cx - 12, sh_y + 22); hr = (cx + 12, sh_y + 24)
    elif pose == "slump":
        hl = (cx - sw - 2, hip_y + 4); hr = (cx + sw + 2, hip_y + 4)
    elif pose == "point":
        hl = (cx - sw - 2, hip_y); hr = (cx + far, sh_y + 2)
    elif pose == "hover":
        hl = (cx - sw - 2, hip_y); hr = (cx + sw + 8, sh_y - 8)
    else:  # float
        hl = (cx - sw - 8, sh_y + 20); hr = (cx + sw + 8, sh_y + 20)
    for (sx, sy), (hx, hy) in ((L, hl), (R, hr)):
        ex = (sx + hx) // 2 + (2 if hx > sx else -2)
        ey = (sy + hy) // 2
        d.line([(sx, sy), (ex, ey), (hx, hy)], fill=BLACK, width=4)
        d.ellipse([hx - 3, hy - 3, hx + 3, hy + 3], fill=BLACK)      # hand
        # spread fingers for reaching/casting
        if pose in ("reach", "arms_out", "arms_raised", "crucifix"):
            for fa in (-35, -12, 12, 35):
                fxp = hx + int(6 * math.cos(math.radians(90 + fa)))
                fyp = hy - int(6 * math.sin(math.radians(90 + fa)))
                d.line([(hx, hy), (fxp, fyp)], fill=BLACK, width=1)
    return (hl, hr)


def _draw_curled(d, cx, cy, r, eyes, aura, fx):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=BLACK)              # curled body
    hr = max(6, r // 2)
    hx, hy = cx, cy - r + hr // 2
    d.ellipse([hx - hr, hy - hr, hx + hr, hy + hr], fill=BLACK)
    lr = max(2, hr // 2)
    _lens(d, hx - hr // 2, hy, lr, eyes)
    _lens(d, hx + hr // 2, hy, lr, eyes)
    d.arc([cx - r, cy - r, cx + r, cy + r], 20, 160, fill=WHITE, width=1)


# --------------------------------------------------------------------------- #
# Aura + floating effects
# --------------------------------------------------------------------------- #
def _aura(d, cx, cy, w, h, aura):
    if aura == "none":
        return
    R = int(w * 0.52)
    if aura == "waves":
        for rr in (R, R + 7):
            d.arc([cx - rr, cy - rr, cx + rr, cy + rr], 300, 60, fill=BLACK)
            d.arc([cx - rr, cy - rr, cx + rr, cy + rr], 120, 240, fill=BLACK)
    elif aura == "lightning":
        for a in (25, 80, 155, 205, 285, 335):
            x0 = cx + int(R * 0.6 * math.cos(math.radians(a)))
            y0 = cy + int(R * 0.6 * math.sin(math.radians(a)))
            x1 = cx + int(R * math.cos(math.radians(a)))
            y1 = cy + int(R * math.sin(math.radians(a)))
            xm = (x0 + x1) // 2 + (4 if a % 2 else -4)
            d.line([(x0, y0), (xm, (y0 + y1) // 2), (x1, y1)], fill=BLACK)
    elif aura == "flame":
        for a in range(0, 360, 40):
            fx0 = cx + int(R * 0.9 * math.cos(math.radians(a)))
            fy0 = cy + int(R * 0.9 * math.sin(math.radians(a)))
            d.polygon([(fx0 - 3, fy0 + 4), (fx0 + 3, fy0 + 4), (fx0, fy0 - 5)], fill=BLACK)
    elif aura == "smoke":
        for i in range(3):
            sx = cx - 10 + i * 10
            d.arc([sx - 4, cy - h // 2 - 6, sx + 4, cy - h // 2 + 6], 0, 360, fill=BLACK)
    elif aura == "void":
        for a in range(0, 360, 30):
            x1 = cx + int(R * math.cos(math.radians(a)))
            y1 = cy + int(R * math.sin(math.radians(a)))
            x0 = cx + int(R * 0.7 * math.cos(math.radians(a)))
            y0 = cy + int(R * 0.7 * math.sin(math.radians(a)))
            d.line([(x0, y0), (x1, y1)], fill=BLACK, width=2)
    elif aura == "halo":
        d.ellipse([cx - 12, cy - 22, cx + 12, cy - 14], outline=BLACK, width=2)
    elif aura == "static":
        import random as _r
        for _ in range(26):
            px = cx + _r.randint(-R, R); py = cy + _r.randint(-R // 2, R)
            d.point((px, py), fill=BLACK)


def _fx(d, cx, head_cy, head_r, w, h, fx, hands=None):
    if fx == "none":
        return
    if fx == "zzz":
        for i, s in enumerate("zzz"):
            d.text((cx + head_r + 2 + i * 5, head_cy - head_r - i * 5), s, font=F_SM, fill=BLACK)
    elif fx == "tarot":
        tx, ty = cx + int(w * 0.32), head_cy - head_r - 4
        d.rectangle([tx, ty, tx + 9, ty + 13], outline=BLACK)
        d.line([(tx + 2, ty + 4), (tx + 7, ty + 4)], fill=BLACK)
        d.line([(tx + 4, ty + 2), (tx + 4, ty + 10)], fill=BLACK)
    elif fx == "skull":
        sx, sy = cx + int(w * 0.34), head_cy
        d.ellipse([sx - 4, sy - 4, sx + 4, sy + 4], fill=WHITE, outline=BLACK)
        d.point((sx - 2, sy - 1), fill=BLACK); d.point((sx + 2, sy - 1), fill=BLACK)
        d.line([(sx - 2, sy + 3), (sx + 2, sy + 3)], fill=BLACK)
    elif fx == "chains":
        hx = hands[0][0] if hands else cx - int(w * 0.3)
        hy = (hands[0][1] if hands else head_cy) + 4
        for i in range(3):
            d.ellipse([hx - 2, hy + i * 6, hx + 2, hy + i * 6 + 5], outline=BLACK)
    elif fx == "ghost":
        gx, gy = cx + int(w * 0.34), head_cy + 6
        d.pieslice([gx - 5, gy - 6, gx + 5, gy + 4], 180, 360, fill=WHITE, outline=BLACK)
        d.rectangle([gx - 5, gy - 1, gx + 5, gy + 4], fill=WHITE, outline=None)
        d.line([(gx - 5, gy + 4), (gx - 2, gy + 1), (gx + 1, gy + 4), (gx + 5, gy + 1)], fill=BLACK)
        d.point((gx - 2, gy - 1), fill=BLACK); d.point((gx + 2, gy - 1), fill=BLACK)
    elif fx == "blood":
        hx = hands[1][0] if hands else cx + int(w * 0.3)
        hy = (hands[1][1] if hands else head_cy) + 3
        for i in range(3):
            d.line([(hx + i * 3 - 3, hy), (hx + i * 3 - 3, hy + 6 + i)], fill=BLACK)
    elif fx == "crown":
        cwd = head_r + 2
        base = head_cy - head_r - 8
        pts = [(cx - cwd, base), (cx - cwd // 2, base - 6), (cx, base),
               (cx + cwd // 2, base - 6), (cx + cwd, base)]
        d.line(pts, fill=BLACK, width=2)
    elif fx == "question":
        d.text((cx + head_r + 2, head_cy - head_r - 6), "?", font=F_MED, fill=BLACK)


# --------------------------------------------------------------------------- #
# Full 250x122 screen
# --------------------------------------------------------------------------- #
def _bar(d, x, y, w, h, pct, label):
    if label:
        d.text((x, y - 9), label, font=F_SM, fill=BLACK)
    d.rectangle([x, y, x + w, y + h], outline=BLACK)
    fw = int((w - 2) * max(0, min(100, pct)) / 100)
    if fw > 0:
        d.rectangle([x + 1, y + 1, x + 1 + fw, y + h - 1], fill=BLACK)


def render_screen(snap, size=(WIDTH, HEIGHT), bob=0):
    W, H = size
    img = Image.new("1", (W, H), WHITE)
    d = ImageDraw.Draw(img)

    fw = int(W * 0.37)
    draw_figure(img, (0, bob, fw, H - 14), snap.get("sprite", {}))
    d.line([(fw + 2, 2), (fw + 2, H - 16)], fill=BLACK)

    rx = fw + 8
    name = snap.get("name", "Psycho Mantis")
    while name and _tw(d, name, F_BIG) > W - rx - 2:
        name = name[:-1]
    d.text((rx, 1), name, font=F_BIG, fill=BLACK)
    lv = snap.get("level", 1)
    d.text((rx, 17), f"LV {lv}/{snap.get('level_cap', 100)} {snap.get('rank','')[:12]}",
           font=F_SM, fill=BLACK)

    bw = W - rx - 4
    _bar(d, rx, 36, bw, 6, snap.get("psyche_pct", 0), "PSY")
    _bar(d, rx, 52, bw, 6, snap.get("xp_pct", 0), "XP")
    _bar(d, rx, 68, bw, 6, snap.get("darkness", 0), "DARK")

    st = snap.get("stats", {})
    d.text((rx, 78), f"◇{snap.get('souls',0)} souls   infamy {snap.get('infamy',0)}",
           font=F_SM, fill=BLACK)
    d.text((rx, 90), f"K{st.get('kills',0)} N{st.get('kidnappings',0)} "
                     f"P{st.get('possessions',0)} nets{st.get('networks_sensed',0)}",
           font=F_SM, fill=BLACK)

    # bottom phrase bar (inverted)
    d.rectangle([0, H - 13, W, H], fill=BLACK)
    phrase = _truncate(d, snap.get("phrase", "..."), F_SM, W - 6)
    d.text((3, H - 12), phrase, font=F_SM, fill=WHITE)
    return img


def _truncate(d, s, f, maxw):
    if _tw(d, s, f) <= maxw:
        return s
    while s and _tw(d, s + "…", f) > maxw:
        s = s[:-1]
    return s + "…"


# --------------------------------------------------------------------------- #
# Display driver
# --------------------------------------------------------------------------- #
class EInkDisplay:
    def __init__(self, home=None, rotate=0, driver="auto"):
        self.rotate = rotate
        self.mode = "preview"
        self.epd = None
        self.inky = None
        self.preview_dir = os.path.join(
            home or os.path.join(os.path.expanduser("~"), ".psychomantis"), "eink")
        os.makedirs(self.preview_dir, exist_ok=True)
        self._init_driver(driver)

    def _init_driver(self, driver):
        if driver in ("auto", "waveshare"):
            for mod in ("epd2in13_V4", "epd2in13_V3", "epd2in13_V2", "epd2in13"):
                try:
                    pkg = __import__(f"waveshare_epd.{mod}", fromlist=[mod])
                    self.epd = pkg.EPD(); self.epd.init()
                    try:
                        self.epd.Clear(0xFF)
                    except Exception:
                        pass
                    self.mode = "waveshare"; return
                except Exception:
                    continue
        if driver in ("auto", "inky"):
            try:
                from inky.auto import auto
                self.inky = auto(); self.mode = "inky"; return
            except Exception:
                pass
        self.mode = "preview"

    def show(self, snap, bob=0):
        img = render_screen(snap, bob=bob)
        if self.rotate:
            img = img.rotate(self.rotate, expand=True)
        if self.mode == "waveshare" and self.epd is not None:
            try:
                buf = self.epd.getbuffer(img)
                (self.epd.displayPartial if hasattr(self.epd, "displayPartial")
                 else self.epd.display)(buf)
                return "waveshare"
            except Exception:
                pass
        if self.mode == "inky" and self.inky is not None:
            try:
                self.inky.set_image(img.convert("P")); self.inky.show(); return "inky"
            except Exception:
                pass
        path = os.path.join(self.preview_dir, "screen.png")
        img.convert("L").resize((WIDTH * 3, HEIGHT * 3), Image.NEAREST).save(path)
        img.convert("L").save(os.path.join(self.preview_dir, "screen_1x.png"))
        return path

    def sleep(self):
        if self.mode == "waveshare" and self.epd is not None:
            try:
                self.epd.sleep()
            except Exception:
                pass


def _button_actions(engine):
    """Default physical-button behaviours."""
    from . import spells

    def cast_best():
        pet = engine.pet
        order = sorted(pet.unlocked_spells,
                       key=lambda s: spells.SPELLS[s].min_level, reverse=True)
        for sid in order:
            if pet.psyche >= spells.SPELLS[sid].psyche_cost:
                try:
                    spells.cast(engine, sid)
                except Exception:
                    pass
                return
        try:
            spells.cast(engine, "mind_reading")
        except Exception:
            pass

    def do_deed():
        for name in ("sever", "kidnap", "possess", "haunt"):
            spec = engine.DEEDS[name]
            if engine.pet.level >= spec["min_level"]:
                res = engine.deed(name)
                if res.get("ok"):
                    return
        engine.harvest()

    return {"feed": engine.feed, "meditate": engine.meditate,
            "pet": engine.pet_it, "cast": cast_best, "deed": do_deed}


IDLE_MOODS_FOR_BOB = {"watching", "listening", "observing", "serene", "content",
                      "tranquil", "meditative", "drowsy", "dreaming", "floating"}


def run_eink(engine, interval=30, rotate=0, driver="auto", autonomous=True,
             use_buttons=True, animate=True, pins=None):
    from . import spells
    from .buttons import ButtonPad

    disp = EInkDisplay(home=engine.home, rotate=rotate, driver=driver)
    print(f"  [eink] driver = {disp.mode}")
    if disp.mode == "preview":
        print(f"  [eink] no panel found — previews -> {disp.preview_dir}")

    force = threading.Event()
    pad = None
    if use_buttons:
        def _wrap(fn):
            def run():
                fn()
                force.set()
            return run
        wrapped = {name: _wrap(fn) for name, fn in _button_actions(engine).items()}
        pad = ButtonPad(wrapped, pins=pins)
        print(f"  [eink] buttons = {'ON  (' + pad.describe() + ')' if pad.available else 'not found'}")

    last_sig = None
    last_auto = 0.0
    last_tick = 0.0
    last_bob = 0.0
    frame = 0
    bob_px = 0
    try:
        while True:
            now = time.time()
            if now - last_tick > min(5, interval):
                engine.tick()
                if autonomous and now - last_auto > max(interval, 40):
                    spells.autonomous_sense(engine); last_auto = now
                engine.save()
                last_tick = now

            snap = engine.snapshot()
            # idle bob animation (2-frame float) — only when calm
            draw_bob = False
            if animate and snap["mood"] in IDLE_MOODS_FOR_BOB and now - last_bob > 3.0:
                frame ^= 1
                bob_px = 2 if frame else 0
                last_bob = now
                draw_bob = True

            sig = (snap["mood"], snap["phrase"], snap["level"],
                   int(snap["psyche_pct"]), int(snap["xp_pct"]), int(snap["darkness"]))
            if sig != last_sig or force.is_set() or draw_bob:
                where = disp.show(snap, bob=bob_px)
                if sig != last_sig or force.is_set():
                    print(f"  [eink] refreshed ({snap['mood']}) -> {where}")
                last_sig = sig
                force.clear()
            time.sleep(0.15)
    except KeyboardInterrupt:
        pass
    finally:
        engine.save(); disp.sleep()
        if pad is not None:
            pad.cleanup()
        print("\n  The mask goes dark. I am always listening...\n")


# --------------------------------------------------------------------------- #
# Preview baking
# --------------------------------------------------------------------------- #
def bake_faces(outdir, scale=3, moods=None):
    from . import personality as P
    os.makedirs(outdir, exist_ok=True)
    demo = {"name": "Psycho Mantis", "level": 66, "level_cap": 100,
            "rank": "Phantom", "psyche_pct": 74, "xp_pct": 48, "darkness": 61,
            "souls": 128, "infamy": 44,
            "stats": {"kills": 13, "kidnappings": 9, "possessions": 27,
                      "networks_sensed": 88}}
    moods = moods or list(P.MOODS.keys())
    paths = []
    for mood in moods:
        meta = P.MOODS[mood]
        snap = dict(demo, mood=mood, phrase=P.pick(meta["p"]),
                    sprite={"eyes": meta["eyes"], "aura": meta["aura"],
                            "pose": meta["pose"], "fx": meta["fx"]})
        img = render_screen(snap).convert("L").resize(
            (WIDTH * scale, HEIGHT * scale), Image.NEAREST)
        p = os.path.join(outdir, f"mantis_{mood}.png")
        img.save(p); paths.append(p)
    # contact sheet of a representative set
    show = moods[:24]
    cols = 4
    rows = (len(show) + cols - 1) // cols
    cw, ch, pad = WIDTH, HEIGHT, 6
    sheet = Image.new("L", (cols * cw + pad * (cols + 1), rows * ch + pad * (rows + 1)), WHITE)
    for i, mood in enumerate(show):
        meta = P.MOODS[mood]
        snap = dict(demo, mood=mood, phrase=mood.upper().replace("_", " "),
                    sprite={"eyes": meta["eyes"], "aura": meta["aura"],
                            "pose": meta["pose"], "fx": meta["fx"]})
        tile = render_screen(snap).convert("L")
        r, c = divmod(i, cols)
        sheet.paste(tile, (pad + c * (cw + pad), pad + r * (ch + pad)))
    sp = os.path.join(outdir, "contact_sheet.png")
    sheet.save(sp); paths.append(sp)
    return paths
