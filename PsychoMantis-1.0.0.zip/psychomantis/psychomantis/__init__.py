"""PsychoMantis — a psychic Tamagotchi-style companion.

A moody, autonomous virtual pet inspired by the pwnagotchi / Bjorn / handheld
recon-pet lineage, re-skinned as Psycho Mantis of FOXHOUND. It lives on its
own, senses the ether around it (passive, benign recon only), gains XP, levels
up, learns "spells" (tools), and reacts to you with faces, moods and phrases.

Safety note: PsychoMantis performs ONLY passive / self-directed, non-harmful
operations (listing visible Wi-Fi networks the way any OS already does, mapping
*your own* local subnet, auditing *your own* machine's open ports). It contains
no deauthentication, packet injection, handshake capture, or password-cracking
code of any kind. It is a pet and a learning toy, not an attack tool.
"""

__version__ = "1.0.0"
__all__ = ["__version__"]
