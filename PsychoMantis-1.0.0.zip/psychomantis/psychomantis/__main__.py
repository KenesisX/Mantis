"""Command-line entry point.

Usage:
    python -m psychomantis            # launch web dashboard (default)
    python -m psychomantis web        # web dashboard
    python -m psychomantis tui        # live terminal pet
    python -m psychomantis status     # one-shot status print
    python -m psychomantis cast <id>  # cast a spell once from the shell
    python -m psychomantis feed|rest|meditate|pet
    python -m psychomantis spells      # list the spellbook
"""

from __future__ import annotations

import argparse
import json
import os
import sys

from . import __version__
from .engine import Engine
from .spells import SPELLS, cast, spell_catalog, SpellError


def main(argv=None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    ap = argparse.ArgumentParser(prog="psychomantis",
                                 description="PsychoMantis — a psychic Tamagotchi.")
    ap.add_argument("command", nargs="?", default="web",
                    help="web | eink | faces | tui | status | spells | cast | "
                         "feed | rest | meditate | pet | possess | kidnap | sever | "
                         "haunt | harvest | shop | buy")
    ap.add_argument("arg", nargs="?", default=None, help="id for 'cast' / 'buy'")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8777)
    ap.add_argument("--home", default=None, help="state directory")
    ap.add_argument("--interval", type=int, default=30, help="eink refresh seconds")
    ap.add_argument("--rotate", type=int, default=0, help="eink rotation (0/90/180/270)")
    ap.add_argument("--driver", default="auto", help="eink driver: auto|waveshare|inky")
    ap.add_argument("--out", default=None, help="output dir for 'faces'")
    ap.add_argument("--no-buttons", action="store_true", help="disable GPIO buttons")
    ap.add_argument("--no-animate", action="store_true", help="disable idle bob")
    ap.add_argument("--pins", default=None,
                    help="button pins, e.g. feed=5,meditate=6,pet=16,cast=24,deed=26")
    ap.add_argument("--version", action="version", version=f"PsychoMantis {__version__}")
    ns = ap.parse_args(argv)

    engine = Engine(home=ns.home)
    cmd = ns.command.lower()

    if cmd == "web":
        from .server import serve
        serve(engine, host=ns.host, port=ns.port)
        return 0

    if cmd == "tui":
        from .tui import run
        run(engine)
        return 0

    if cmd == "eink":
        try:
            from .eink import run_eink
        except ImportError:
            print("The e-ink display needs Pillow:  pip install pillow")
            print("On a Raspberry Pi panel also:     pip install waveshare-epd  (or inky)")
            return 1
        from .buttons import parse_pins
        run_eink(engine, interval=ns.interval, rotate=ns.rotate, driver=ns.driver,
                 use_buttons=not ns.no_buttons, animate=not ns.no_animate,
                 pins=parse_pins(ns.pins))
        return 0

    if cmd == "faces":
        try:
            from .eink import bake_faces
        except ImportError:
            print("Baking faces needs Pillow:  pip install pillow")
            return 1
        outdir = ns.out or os.path.join(engine.home, "faces")
        paths = bake_faces(outdir)
        print(f"Wrote {len(paths)} previews to {outdir}")
        for p in paths:
            print("  " + p)
        return 0

    if cmd == "status":
        engine.tick()
        snap = engine.snapshot()
        print(f"{snap['name']}  lv{snap['level']}/{snap['level_cap']} ({snap['rank']})")
        print(f"mood: {snap['mood']}  psyche: {int(snap['psyche'])}/{int(snap['psyche_max'])}"
              f"  age: {snap['age']}")
        print(f"xp: {snap['xp']}/{snap['xp_to_next']}   "
              f"◇{snap['souls']} souls   darkness {snap['darkness']}   infamy {snap['infamy']}")
        n = snap["needs"]
        print(f"hunger {n['hunger']}  energy {n['energy']}  "
              f"focus {n['focus']}  sanity {n['sanity']}")
        st = snap["stats"]
        print(f"kills {st['kills']}  kidnaps {st['kidnappings']}  "
              f"possess {st['possessions']}  harvested {st['souls_harvested']}")
        print(f'"{snap["phrase"]}"')
        return 0

    if cmd == "spells":
        for sp in spell_catalog(engine.pet.unlocked_spells, engine.pet.level):
            lock = "" if sp["unlocked"] else f"  [LOCKED lv{sp['min_level']}]"
            print(f"{sp['glyph']}  {sp['id']:<16} {sp['name']:<20} "
                  f"cost {sp['psyche_cost']:>2}  +{sp['xp']}xp{lock}")
        return 0

    if cmd == "cast":
        if not ns.arg:
            print("usage: python -m psychomantis cast <spell_id>")
            print("try:   python -m psychomantis spells")
            return 2
        try:
            res = cast(engine, ns.arg)
        except SpellError as e:
            print(f"✖ {e}")
            return 1
        print(res.get("summary"))
        for item in res.get("items", [])[:20]:
            print("   ", json.dumps(item))
        engine.save()
        return 0

    if cmd in ("feed", "rest", "meditate", "pet"):
        fn = {"feed": engine.feed, "rest": engine.rest,
              "meditate": engine.meditate, "pet": engine.pet_it}[cmd]
        print(fn())
        engine.save()
        return 0

    if cmd in ("possess", "kidnap", "sever", "haunt"):
        res = engine.deed(cmd)
        print(res.get("summary") if res.get("ok") else f"✖ {res.get('error')}")
        engine.save()
        return 0 if res.get("ok") else 1

    if cmd == "harvest":
        res = engine.harvest()
        print(res.get("summary") if res.get("ok") else f"✖ {res.get('error')}")
        engine.save()
        return 0 if res.get("ok") else 1

    if cmd == "shop":
        from . import upgrades as U
        print(f"SOULS: ◇{engine.pet.souls}\n")
        for a in U.catalog(engine.pet):
            price = "MAX" if a["maxed"] else f"◇{a['cost']}"
            print(f"{a['glyph']}  {a['id']:<14} T{a['tier']}/{a['max_tier']}  "
                  f"{price:<6} {a['name']} — {a['desc']}")
        print("\nbuy with:  python -m psychomantis buy <id>")
        return 0

    if cmd == "buy":
        if not ns.arg:
            print("usage: python -m psychomantis buy <augment_id>  (see 'shop')")
            return 2
        res = engine.buy_augment(ns.arg)
        print(f"Bought {res['augment']} tier {res['tier']} (−◇{res['spent']})"
              if res.get("ok") else f"✖ {res.get('error')}")
        engine.save()
        return 0 if res.get("ok") else 1

    print(f"Unknown command: {cmd}")
    ap.print_help()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
