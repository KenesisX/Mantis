"use strict";
// PsychoMantis dashboard — talks to the stdlib JSON API.

const $ = (id) => document.getElementById(id);
let STATE = null;
let SPELLS = [];

async function api(path, body) {
  const opt = body
    ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }
    : {};
  const r = await fetch(path, opt);
  return r.json();
}

function toast(msg) {
  const t = document.createElement("div");
  t.className = "toast";
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2600);
}

function shake(effect) {
  const root = $("shake-root");
  const cls = effect === "scream" ? "scream" : "shake";
  root.classList.remove("shake", "scream");
  void root.offsetWidth;
  root.classList.add(cls);
  setTimeout(() => root.classList.remove(cls), 1200);
}

// ---- rendering ------------------------------------------------------- //
function render(s) {
  if (!s) return;
  STATE = s;
  $("pet-name").textContent = s.name;
  $("rank").textContent = s.rank;
  $("level").textContent = s.level;
  $("age").textContent = "age " + s.age;
  $("xp-text").textContent = `${s.xp} / ${s.xp_to_next}`;
  $("xp-fill").style.width = s.xp_pct + "%";
  $("psy-text").textContent = `${Math.round(s.psyche)} / ${Math.round(s.psyche_max)}`;
  $("psy-fill").style.width = (s.psyche_pct ?? 0) + "%";
  $("dark-text").textContent = Math.round(s.darkness);
  $("dark-fill").style.width = (s.darkness ?? 0) + "%";
  $("souls").textContent = s.souls ?? 0;
  $("infamy").textContent = s.infamy ?? 0;
  // darkness tints the whole page
  document.body.style.setProperty("--dark-level", (s.darkness ?? 0) / 100);
  document.getElementById("shake-root").style.filter =
    s.darkness > 70 ? "contrast(1.12) brightness(.92)" : "none";
  $("n-hunger").style.width = s.needs.hunger + "%";
  $("n-energy").style.width = s.needs.energy + "%";
  $("n-focus").style.width = s.needs.focus + "%";
  $("n-sanity").style.width = s.needs.sanity + "%";
  $("speech").textContent = s.phrase;

  // face expression
  const mask = $("mask");
  mask.setAttribute("class", "mask " + (s.face_web || "watching"));

  // counters
  const st = s.stats;
  $("counters").innerHTML = [
    ["kills", "severed"], ["kidnappings", "kidnapped"], ["possessions", "possessed"],
    ["souls_harvested", "harvested"], ["networks_sensed", "minds heard"],
    ["spells_cast", "spells"], ["meditations", "meditations"], ["best_level", "peak lv"],
  ].map(([k, lbl]) => `<div class="c"><b>${st[k] ?? 0}</b><span>${lbl}</span></div>`).join("");

  // captives bar + tab
  const pawns = s.pawns || [];
  $("pawnbar").textContent = pawns.length
    ? `${pawns.length} mind(s) held captive — ready to harvest.`
    : "No minds captured.";
  renderList("tab-pawns", pawns, (p) =>
    `<div class="row"><span class="k">${p.deed === "kidnap" ? "⛓" : "🌀"} ${esc(p.who)}</span>
      <span class="v">${esc(p.deed)}</span></div>`);

  renderLog(s.log);
  renderList("tab-nets", s.known_networks, (n) =>
    `<div class="row"><span class="k">📡 ${esc(n.ssid)}</span>
      <span class="v">${n.signal ?? "?"}% · ${esc(n.security || "?")}${n.sim ? " · sim" : ""}</span></div>`);
  renderList("tab-devs", s.known_devices, (d) =>
    `<div class="row"><span class="k">👤 ${esc(d.ip)}</span>
      <span class="v">${esc(d.name || "unknown")}${d.sim ? " · sim" : ""}</span></div>`);
  $("tab-ach").innerHTML = (s.achievements && s.achievements.length)
    ? s.achievements.map((a) => `<span class="badge">★ ${esc(a)}</span>`).join("")
    : `<div class="logline">No relics yet. Grow stronger.</div>`;
}

function renderLog(log) {
  $("tab-log").innerHTML = (log || []).slice().reverse().map((e) =>
    `<div class="logline ${esc(e.kind)}"><span class="ts">${esc(e.ts)}</span>${esc(e.text)}</div>`
  ).join("");
}

function renderList(id, items, fn) {
  const el = $(id);
  if (!items || !items.length) { el.innerHTML = `<div class="logline">Nothing sensed yet.</div>`; return; }
  el.innerHTML = items.slice().reverse().map(fn).join("");
}

function renderSpells() {
  $("spellgrid").innerHTML = SPELLS.map((sp) => `
    <div class="spell ${sp.unlocked ? "" : "locked"}" data-spell="${sp.id}">
      <span class="school">${esc(sp.school)}</span>
      <div class="g">${sp.glyph}</div>
      <div class="nm">${esc(sp.name)}</div>
      <div class="meta"><span class="cost">◈${sp.psyche_cost}</span> ·
        <span class="xpv">+${sp.xp}xp</span>
        ${sp.unlocked ? "" : ` · 🔒lv${sp.min_level}`}</div>
      <div class="d">${esc(sp.desc)}</div>
    </div>`).join("");
  document.querySelectorAll(".spell").forEach((el) => {
    el.addEventListener("click", () => doCast(el.dataset.spell));
  });
}

const esc = (s) => String(s == null ? "" : s)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

// ---- actions --------------------------------------------------------- //
async function doAction(action) {
  const res = await api("/api/action", { action });
  if (res.message) toast(res.message);
  if (res.state) render(res.state);
}

async function doCast(spellId) {
  const sp = SPELLS.find((x) => x.id === spellId);
  if (sp && !sp.unlocked) { toast(`🔒 Locked — reach level ${sp.min_level}`); return; }
  const res = await api("/api/cast", { spell: spellId });
  if (!res.ok) { toast("✖ " + (res.error || "cast failed")); if (res.state) render(res.state); return; }
  const r = res.result || {};
  if (r.effect === "shake") shake("shake");
  if (r.effect === "scream") shake("scream");
  showModal(r);
  if (res.state) render(res.state);
  // refresh spellbook unlock state
  const sres = await api("/api/spells");
  SPELLS = sres.spells; renderSpells();
}

async function doDeed(deed) {
  const res = await api("/api/deed", { deed });
  if (!res.ok) { toast("✖ " + (res.error || "blocked")); if (res.state) render(res.state); return; }
  shake("shake");
  toast(res.summary || "deed done");
  if (res.state) render(res.state);
  refreshSpellsUnlock();
}

async function doHarvest() {
  const res = await api("/api/harvest", {});
  toast(res.ok ? (res.summary || "harvested") : ("✖ " + (res.error || "nothing to harvest")));
  if (res.state) render(res.state);
}

async function loadShop() {
  const res = await api("/api/augments");
  const augs = res.augments || [];
  $("shopgrid").innerHTML = augs.map((a) => {
    const cls = a.maxed ? "aug maxed" : (a.affordable ? "aug" : "aug poor");
    const price = a.maxed ? "MAX" : `◇${a.cost}`;
    return `<div class="${cls}" data-aug="${a.id}">
      <span class="atier">T${a.tier}/${a.max_tier}</span>
      <div class="ag">${a.glyph}</div><div class="an">${esc(a.name)}</div>
      <div class="ad">${esc(a.desc)}</div>
      <div class="acost">${price}</div></div>`;
  }).join("");
  document.querySelectorAll(".aug").forEach((el) =>
    el.addEventListener("click", () => doBuy(el.dataset.aug)));
}

async function doBuy(id) {
  const res = await api("/api/buy", { augment: id });
  toast(res.ok ? `Augment → tier ${res.tier} (−◇${res.spent})` : ("✖ " + (res.error || "cannot buy")));
  if (res.state) render(res.state);
  loadShop();
}

async function refreshSpellsUnlock() {
  const sres = await api("/api/spells");
  SPELLS = sres.spells; renderSpells();
}

function showModal(r) {
  $("modal-title").textContent = r.spell || "Spell";
  $("modal-summary").textContent = r.summary || "";
  const items = r.items || [];
  $("modal-items").innerHTML = items.length
    ? items.map((it) => `<div class="row"><span class="k">${esc(fmtItem(it))}</span></div>`).join("")
    : `<div class="logline">(no echoes returned)</div>`;
  $("modal").classList.remove("hidden");
}

function fmtItem(it) {
  if (it.ssid) return `📡 ${it.ssid}  —  ${it.signal ?? "?"}%  ${it.security || ""}`;
  if (it.ip && it.port === undefined) return `👤 ${it.ip}  ${it.name || ""}${it.present !== undefined ? (it.present ? "  ✅ present" : "  — away") : ""}`;
  if (it.port !== undefined) return `🚪 ${it.port}/${it.service}${it.risky ? "  ⚠ exposed" : ""}`;
  if (it.hop !== undefined) return `🌌 hop ${it.hop}  ${it.ip}`;
  if (it.address) return `💠 ${it.address}`;
  return JSON.stringify(it);
}

// ---- tabs ------------------------------------------------------------ //
document.querySelectorAll(".tab").forEach((t) => {
  t.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((x) => x.classList.remove("active"));
    document.querySelectorAll(".tabview").forEach((x) => x.classList.add("hidden"));
    t.classList.add("active");
    $("tab-" + t.dataset.tab).classList.remove("hidden");
  });
});

document.querySelectorAll("[data-action]").forEach((b) =>
  b.addEventListener("click", () => doAction(b.dataset.action)));
document.querySelectorAll("[data-deed]").forEach((b) =>
  b.addEventListener("click", () => doDeed(b.dataset.deed)));
document.querySelectorAll("[data-harvest]").forEach((b) =>
  b.addEventListener("click", () => doHarvest()));
$("rename-btn").addEventListener("click", async () => {
  const name = prompt("A new name for the Mantis:", STATE ? STATE.name : "");
  if (name) { const r = await api("/api/rename", { name }); if (r.state) render(r.state); }
});
$("modal-close").addEventListener("click", () => $("modal").classList.add("hidden"));
$("modal").addEventListener("click", (e) => { if (e.target.id === "modal") $("modal").classList.add("hidden"); });

// animated codec frequency flicker
setInterval(() => {
  const f = (140 + Math.random() * 0.9).toFixed(2);
  $("freq").textContent = f;
}, 3000);

// ---- poll loop ------------------------------------------------------- //
async function tick() {
  try {
    const s = await api("/api/state");
    render(s);
    $("status-dot").textContent = "● live"; $("status-dot").style.color = "var(--green)";
  } catch (e) {
    $("status-dot").textContent = "● offline"; $("status-dot").style.color = "var(--red)";
  }
}

(async function init() {
  const sres = await api("/api/spells");
  SPELLS = sres.spells; renderSpells();
  await loadShop();
  await tick();
  setInterval(tick, 3000);
})();
