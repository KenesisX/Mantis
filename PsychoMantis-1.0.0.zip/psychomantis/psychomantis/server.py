"""Stdlib HTTP server: JSON API + the web dashboard. No dependencies."""

from __future__ import annotations

import json
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict

from .engine import Engine
from .spells import SPELLS, cast, spell_catalog, autonomous_sense, SpellError
from . import upgrades as U

WEB_DIR = os.path.join(os.path.dirname(__file__), "web")


class _Handler(BaseHTTPRequestHandler):
    engine: Engine = None  # type: ignore[assignment]

    def log_message(self, *a: Any) -> None:  # silence
        pass

    # -- helpers ---------------------------------------------------- #
    def _send(self, code: int, body: bytes, ctype: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except Exception:
            pass

    def _json(self, obj: Dict[str, Any], code: int = 200) -> None:
        self._send(code, json.dumps(obj).encode("utf-8"), "application/json")

    def _file(self, name: str, ctype: str) -> None:
        path = os.path.join(WEB_DIR, name)
        try:
            with open(path, "rb") as fh:
                self._send(200, fh.read(), ctype)
        except FileNotFoundError:
            self._send(404, b"not found", "text/plain")

    def _read_body(self) -> Dict[str, Any]:
        try:
            n = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(n) if n else b"{}"
            return json.loads(raw or b"{}")
        except Exception:
            return {}

    # -- routes ----------------------------------------------------- #
    def do_GET(self) -> None:
        path = self.path.split("?")[0]
        eng = self.engine
        if path in ("/", "/index.html"):
            self._file("index.html", "text/html; charset=utf-8")
        elif path == "/app.js":
            self._file("app.js", "application/javascript")
        elif path == "/style.css":
            self._file("style.css", "text/css")
        elif path == "/api/state":
            eng.tick()
            self._json(eng.snapshot())
        elif path == "/api/spells":
            self._json({"spells": spell_catalog(eng.pet.unlocked_spells, eng.pet.level)})
        elif path == "/api/augments":
            self._json({"augments": U.catalog(eng.pet), "souls": eng.pet.souls})
        else:
            self._send(404, b"not found", "text/plain")

    def do_POST(self) -> None:
        path = self.path.split("?")[0]
        eng = self.engine
        body = self._read_body()
        try:
            if path == "/api/action":
                act = body.get("action")
                fn = {"feed": eng.feed, "rest": eng.rest, "meditate": eng.meditate,
                      "pet": eng.pet_it, "speak": eng.speak}.get(act)
                if not fn:
                    return self._json({"error": "unknown action"}, 400)
                msg = fn()
                return self._json({"ok": True, "message": msg, "state": eng.snapshot()})
            elif path == "/api/cast":
                res = cast(eng, body.get("spell", ""))
                return self._json({"ok": True, "result": res, "state": eng.snapshot()})
            elif path == "/api/deed":
                res = eng.deed(body.get("deed", ""))
                return self._json({**res, "state": eng.snapshot()},
                                  200 if res.get("ok") else 400)
            elif path == "/api/harvest":
                res = eng.harvest()
                return self._json({**res, "state": eng.snapshot()},
                                  200 if res.get("ok") else 400)
            elif path == "/api/buy":
                res = eng.buy_augment(body.get("augment", ""))
                return self._json({**res, "augments": U.catalog(eng.pet),
                                   "state": eng.snapshot()},
                                  200 if res.get("ok") else 400)
            elif path == "/api/rename":
                eng.rename(body.get("name", ""))
                return self._json({"ok": True, "state": eng.snapshot()})
            else:
                return self._json({"error": "not found"}, 404)
        except SpellError as e:
            return self._json({"ok": False, "error": str(e), "state": eng.snapshot()}, 400)
        except Exception as e:  # pragma: no cover
            return self._json({"ok": False, "error": str(e)}, 500)


def _background(engine: Engine, stop: threading.Event) -> None:
    last = 0.0
    while not stop.is_set():
        engine.tick()
        if time.time() - last > 40:
            autonomous_sense(engine)
            last = time.time()
        engine.save()
        stop.wait(5)


def serve(engine: Engine, host: str = "127.0.0.1", port: int = 8777) -> None:
    _Handler.engine = engine
    stop = threading.Event()
    bg = threading.Thread(target=_background, args=(engine, stop), daemon=True)
    bg.start()
    httpd = ThreadingHTTPServer((host, port), _Handler)
    url = f"http://{host}:{port}"
    print("\n  \033[38;5;201m╔════════════════════════════════════════════╗")
    print("  ║   PSYCHO MANTIS is awake and listening...   ║")
    print("  ╚════════════════════════════════════════════╝\033[0m")
    print(f"\n  Open your mind (and browser) at:  \033[38;5;51m{url}\033[0m")
    print("  Press Ctrl+C to let him sleep.\n")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        engine.save()
        httpd.server_close()
        print("\n  The mask goes dark. I am always listening...\n")
